import subprocess
import os

def run_script(script_path):
    """Executa um script Python usando subprocess."""
    print(f"\nExecutando {script_path}...")
    try:
        # Usamos sys.executable para garantir que o script seja executado com o mesmo interpretador Python
        # que está executando este script principal.
        result = subprocess.run(["python3", script_path], capture_output=True, text=True, check=True)
        print(result.stdout)
        if result.stderr:
            print(f"Erros/Warnings de {script_path}:\n{result.stderr}")
    except subprocess.CalledProcessError as e:
        print(f"Erro ao executar {script_path}: {e}")
        print(f"Stdout: {e.stdout}")
        print(f"Stderr: {e.stderr}")
    except FileNotFoundError:
        print(f"Erro: O interpretador 'python3' não foi encontrado. Certifique-se de que Python está instalado e no PATH.")

if __name__ == "__main__":
    project_root = os.path.dirname(os.path.abspath(__file__))
    src_dir = os.path.join(project_root, "src")

    # Caminhos para os scripts
    data_collection_script = os.path.join(src_dir, "data_collection.py")
    data_preprocessing_script = os.path.join(src_dir, "data_preprocessing.py")
    data_analysis_script = os.path.join(src_dir, "data_analysis.py")

    print("Iniciando o fluxo de trabalho do projeto Inclusão Digital e Oportunidades Econômicas...")

    # 1. Coleta de Dados
    run_script(data_collection_script)

    # 2. Pré-processamento de Dados
    run_script(data_preprocessing_script)

    # 3. Análise de Dados
    run_script(data_analysis_script)

    print("\nFluxo de trabalho concluído. Verifique as pastas 'data/raw', 'data/processed' e 'reports/figures'.")


