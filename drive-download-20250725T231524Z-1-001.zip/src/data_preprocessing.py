import pandas as pd
import os
from PyPDF2 import PdfReader
from bs4 import BeautifulSoup

def preprocess_cetic_data(html_path):
    """Pré-processa os dados HTML do Cetic.br."""
    print(f"Pré-processando dados do Cetic.br de: {html_path}")
    with open(html_path, 'r', encoding='utf-8') as f:
        html_content = f.read()
    soup = BeautifulSoup(html_content, 'html.parser')
    # TODO: Implementar a lógica de extração e limpeza de dados do HTML do Cetic.br
    # Exemplo: encontrar tabelas com pd.read_html(html_content)
    # Ou extrair texto específico usando seletores CSS/BeautifulSoup
    print("Pré-processamento do Cetic.br concluído (lógica de extração e limpeza pendente).")
    return pd.DataFrame() # Retorna um DataFrame vazio por enquanto

def preprocess_dados_abertos_sp(html_path):
    """Pré-processa os dados HTML do Dados Abertos SP."""
    print(f"Pré-processando dados do Dados Abertos SP de: {html_path}")
    with open(html_path, 'r', encoding='utf-8') as f:
        html_content = f.read()
    soup = BeautifulSoup(html_content, 'html.parser')
    # TODO: Implementar a lógica de extração e limpeza de dados do HTML do Dados Abertos SP
    # Pode ser necessário navegar por links para baixar datasets CSV/JSON
    print("Pré-processamento do Dados Abertos SP concluído (lógica de extração e limpeza pendente).")
    return pd.DataFrame() # Retorna um DataFrame vazio por enquanto

def extract_text_from_pdf(pdf_path):
    """Extrai texto de um arquivo PDF."""
    print(f"Extraindo texto do PDF: {pdf_path}")
    text = ""
    try:
        with open(pdf_path, 'rb') as f:
            reader = PdfReader(f)
            for page in reader.pages:
                text += page.extract_text() + "\n"
        print("Extração de texto do PDF concluída.")
        return text
    except Exception as e:
        print(f"Erro ao extrair texto do PDF: {e}")
        return None

def preprocess_nossa_sao_paulo_data(pdf_path):
    """Pré-processa os dados do PDF da Nossa São Paulo."""
    print(f"Pré-processando dados do PDF da Nossa São Paulo de: {pdf_path}")
    pdf_text = extract_text_from_pdf(pdf_path)
    if pdf_text:
        # TODO: Implementar a lógica de extração de tabelas ou informações específicas do texto do PDF
        # Isso pode ser complexo e exigir expressões regulares ou bibliotecas como Camelot/Tabula para tabelas
        print("Pré-processamento do PDF da Nossa São Paulo concluído (lógica de extração e limpeza pendente).")
        return pd.DataFrame({"texto_pdf": [pdf_text]}) # Retorna um DataFrame com o texto completo por enquanto
    return pd.DataFrame() # Retorna um DataFrame vazio se a extração falhar

if __name__ == "__main__":
    raw_data_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'raw')
    processed_data_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'processed')
    os.makedirs(processed_data_dir, exist_ok=True)

    # Pré-processar dados do Cetic.br
    cetic_html_path = os.path.join(raw_data_dir, 'cetic_domicilios_2024.html')
    if os.path.exists(cetic_html_path):
        df_cetic = preprocess_cetic_data(cetic_html_path)
        if not df_cetic.empty:
            df_cetic.to_csv(os.path.join(processed_data_dir, 'cetic_processed.csv'), index=False)

    # Pré-processar dados do Dados Abertos SP
    dados_abertos_sp_html_path = os.path.join(raw_data_dir, 'dados_abertos_sp_ciencia_tecnologia.html')
    if os.path.exists(dados_abertos_sp_html_path):
        df_dados_abertos_sp = preprocess_dados_abertos_sp(dados_abertos_sp_html_path)
        if not df_dados_abertos_sp.empty:
            df_dados_abertos_sp.to_csv(os.path.join(processed_data_dir, 'dados_abertos_sp_processed.csv'), index=False)

    # Pré-processar PDF da Nossa São Paulo
    nossa_sao_paulo_pdf_path = os.path.join(raw_data_dir, 'Mapa_da_Desigualdade_2022_Tabelas.pdf')
    if os.path.exists(nossa_sao_paulo_pdf_path):
        df_nossa_sao_paulo = preprocess_nossa_sao_paulo_data(nossa_sao_paulo_pdf_path)
        if not df_nossa_sao_paulo.empty:
            df_nossa_sao_paulo.to_csv(os.path.join(processed_data_dir, 'nossa_sao_paulo_processed.csv'), index=False)

    print("\nPré-processamento de dados concluído. Verifique a pasta 'data/processed'.")


