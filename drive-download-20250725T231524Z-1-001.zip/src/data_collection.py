import requests
from bs4 import BeautifulSoup
import pandas as pd
import os

def collect_cetic_data(url):
    """Coleta dados do Cetic.br."""
    print(f"Coletando dados do Cetic.br de: {url}")
    try:
        response = requests.get(url)
        response.raise_for_status()  # Levanta um erro para códigos de status HTTP ruins
        soup = BeautifulSoup(response.text, 'html.parser')
        # TODO: Implementar a lógica de extração de dados específica para o site do Cetic.br
        # Isso pode envolver encontrar tabelas, links para CSV/Excel, etc.
        print("Coleta do Cetic.br concluída (lógica de extração pendente).")
        return soup.prettify() # Retorna o HTML para inspeção inicial
    except requests.exceptions.RequestException as e:
        print(f"Erro ao coletar dados do Cetic.br: {e}")
        return None

def collect_dados_abertos_sp(url):
    """Coleta dados do portal Dados Abertos SP."""
    print(f"Coletando dados do Dados Abertos SP de: {url}")
    try:
        response = requests.get(url)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        # TODO: Implementar a lógica de extração de dados específica para o portal Dados Abertos SP
        # Geralmente envolve encontrar links para datasets (CSV, JSON, etc.)
        print("Coleta do Dados Abertos SP concluída (lógica de extração pendente).")
        return soup.prettify() # Retorna o HTML para inspeção inicial
    except requests.exceptions.RequestException as e:
        print(f"Erro ao coletar dados do Dados Abertos SP: {e}")
        return None

def collect_nossa_sao_paulo_pdf(url, output_path):
    """Baixa o PDF do Mapa da Desigualdade da Nossa São Paulo."""
    print(f"Baixando PDF da Nossa São Paulo de: {url}")
    try:
        response = requests.get(url, stream=True)
        response.raise_for_status()
        with open(output_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        print(f"PDF baixado com sucesso para: {output_path}")
        return output_path
    except requests.exceptions.RequestException as e:
        print(f"Erro ao baixar PDF da Nossa São Paulo: {e}")
        return None

if __name__ == "__main__":
    # URLs das fontes de dados
    cetic_url = "https://cetic.br/pt/tics/domicilios/2024/individuos/B1/expandido"
    dados_abertos_sp_url = "https://dadosabertos.sp.gov.br/group/ciencia-e-tecnologia"
    nossa_sao_paulo_url = "https://nossasaopaulo.org.br/wp-content/uploads/2022/11/Mapa-da-Desigualdade-2022_Tabelas.pdf"

    # Caminho para salvar os dados brutos
    raw_data_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'raw')
    os.makedirs(raw_data_dir, exist_ok=True)

    # Coleta de dados do Cetic.br
    cetic_html = collect_cetic_data(cetic_url)
    if cetic_html:
        with open(os.path.join(raw_data_dir, 'cetic_domicilios_2024.html'), 'w', encoding='utf-8') as f:
            f.write(cetic_html)

    # Coleta de dados do Dados Abertos SP
    dados_abertos_sp_html = collect_dados_abertos_sp(dados_abertos_sp_url)
    if dados_abertos_sp_html:
        with open(os.path.join(raw_data_dir, 'dados_abertos_sp_ciencia_tecnologia.html'), 'w', encoding='utf-8') as f:
            f.write(dados_abertos_sp_html)

    # Baixar PDF da Nossa São Paulo
    nossa_sao_paulo_pdf_path = os.path.join(raw_data_dir, 'Mapa_da_Desigualdade_2022_Tabelas.pdf')
    collect_nossa_sao_paulo_pdf(nossa_sao_paulo_url, nossa_sao_paulo_pdf_path)

    print("\nColeta de dados brutos concluída. Verifique a pasta 'data/raw'.")


