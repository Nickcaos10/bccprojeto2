import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import os
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

# Configuração de estilo para gráficos
plt.style.use('seaborn-v0_8')
sns.set_palette("husl")

class InclusaoDigitalAnalyzer:
    def __init__(self, data_dir):
        self.data_dir = data_dir
        self.figures_dir = os.path.join(os.path.dirname(data_dir), 'reports', 'figures')
        os.makedirs(self.figures_dir, exist_ok=True)
        self.df_cetic = None
        self.df_dados_abertos = None
        self.df_nossa_sp = None
        
    def load_data(self):
        """Carrega os dados processados."""
        print("Carregando dados processados...")
        
        # Carregar dados do Cetic.br
        cetic_path = os.path.join(self.data_dir, 'cetic_processed.csv')
        if os.path.exists(cetic_path):
            self.df_cetic = pd.read_csv(cetic_path)
            print(f"Dados Cetic carregados: {self.df_cetic.shape}")
        
        # Carregar dados do Dados Abertos SP
        dados_abertos_path = os.path.join(self.data_dir, 'dados_abertos_sp_processed.csv')
        if os.path.exists(dados_abertos_path):
            self.df_dados_abertos = pd.read_csv(dados_abertos_path)
            print(f"Dados Abertos SP carregados: {self.df_dados_abertos.shape}")
        
        # Carregar dados da Nossa São Paulo
        nossa_sp_path = os.path.join(self.data_dir, 'nossa_sao_paulo_processed.csv')
        if os.path.exists(nossa_sp_path):
            self.df_nossa_sp = pd.read_csv(nossa_sp_path)
            print(f"Dados Nossa SP carregados: {self.df_nossa_sp.shape}")
    
    def create_sample_data(self):
        """Cria dados de exemplo para demonstração das análises."""
        print("Criando dados de exemplo para demonstração...")
        
        # Dados de exemplo das periferias de São Paulo
        periferias = ['Capão Redondo', 'Grajaú', 'Guaianases', 'Itaquera', 
                     'Jardim Ângela', 'São Mateus', 'Pirituba', 'Brasilândia', 
                     'Heliópolis', 'Paraisópolis']
        
        np.random.seed(42)  # Para reprodutibilidade
        
        # Simulando dados de inclusão digital e oportunidades econômicas
        data = {
            'regiao': periferias,
            'acesso_internet_pct': np.random.uniform(45, 85, len(periferias)),
            'banda_larga_pct': np.random.uniform(30, 70, len(periferias)),
            'dispositivos_moveis_pct': np.random.uniform(60, 95, len(periferias)),
            'computador_pct': np.random.uniform(20, 60, len(periferias)),
            'cursos_online_pct': np.random.uniform(5, 25, len(periferias)),
            'teletrabalho_pct': np.random.uniform(2, 15, len(periferias)),
            'empreendedorismo_digital_pct': np.random.uniform(3, 18, len(periferias)),
            'renda_media': np.random.uniform(800, 2500, len(periferias)),
            'populacao': np.random.randint(50000, 300000, len(periferias))
        }
        
        self.df_sample = pd.DataFrame(data)
        
        # Criar correlações realistas
        # Regiões com maior acesso à internet tendem a ter mais oportunidades
        for i, regiao in enumerate(periferias):
            base_internet = self.df_sample.loc[i, 'acesso_internet_pct']
            # Ajustar outras variáveis baseadas no acesso à internet
            self.df_sample.loc[i, 'cursos_online_pct'] = base_internet * 0.2 + np.random.normal(0, 2)
            self.df_sample.loc[i, 'teletrabalho_pct'] = base_internet * 0.15 + np.random.normal(0, 1.5)
            self.df_sample.loc[i, 'empreendedorismo_digital_pct'] = base_internet * 0.18 + np.random.normal(0, 2)
            self.df_sample.loc[i, 'renda_media'] = base_internet * 25 + np.random.normal(0, 200)
        
        # Garantir que os valores estejam dentro de limites realistas
        self.df_sample = self.df_sample.clip(lower=0)
        
        print(f"Dados de exemplo criados: {self.df_sample.shape}")
        return self.df_sample
    
    def exploratory_analysis(self):
        """Realiza análise exploratória dos dados."""
        print("Realizando análise exploratória...")
        
        if self.df_sample is None:
            self.create_sample_data()
        
        # Estatísticas descritivas
        print("\n=== ESTATÍSTICAS DESCRITIVAS ===")
        print(self.df_sample.describe())
        
        # Matriz de correlação
        numeric_cols = self.df_sample.select_dtypes(include=[np.number]).columns
        correlation_matrix = self.df_sample[numeric_cols].corr()
        
        # Visualizar matriz de correlação
        plt.figure(figsize=(12, 10))
        sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', center=0, 
                   square=True, linewidths=0.5)
        plt.title('Matriz de Correlação - Inclusão Digital e Oportunidades Econômicas')
        plt.tight_layout()
        plt.savefig(os.path.join(self.figures_dir, 'matriz_correlacao.png'), dpi=300, bbox_inches='tight')
        plt.close()
        
        return correlation_matrix
    
    def analyze_digital_inclusion(self):
        """Analisa os indicadores de inclusão digital."""
        print("Analisando indicadores de inclusão digital...")
        
        if self.df_sample is None:
            self.create_sample_data()
        
        # Gráfico de barras - Acesso à Internet por região
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        
        # Acesso à Internet
        axes[0,0].bar(self.df_sample['regiao'], self.df_sample['acesso_internet_pct'])
        axes[0,0].set_title('Acesso à Internet por Região (%)')
        axes[0,0].tick_params(axis='x', rotation=45)
        
        # Banda Larga
        axes[0,1].bar(self.df_sample['regiao'], self.df_sample['banda_larga_pct'], color='orange')
        axes[0,1].set_title('Acesso à Banda Larga por Região (%)')
        axes[0,1].tick_params(axis='x', rotation=45)
        
        # Dispositivos Móveis
        axes[1,0].bar(self.df_sample['regiao'], self.df_sample['dispositivos_moveis_pct'], color='green')
        axes[1,0].set_title('Acesso a Dispositivos Móveis por Região (%)')
        axes[1,0].tick_params(axis='x', rotation=45)
        
        # Computadores
        axes[1,1].bar(self.df_sample['regiao'], self.df_sample['computador_pct'], color='red')
        axes[1,1].set_title('Acesso a Computadores por Região (%)')
        axes[1,1].tick_params(axis='x', rotation=45)
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.figures_dir, 'inclusao_digital_indicadores.png'), dpi=300, bbox_inches='tight')
        plt.close()
        
        # Gráfico interativo com Plotly
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=('Acesso à Internet', 'Banda Larga', 'Dispositivos Móveis', 'Computadores'),
            specs=[[{"secondary_y": False}, {"secondary_y": False}],
                   [{"secondary_y": False}, {"secondary_y": False}]]
        )
        
        fig.add_trace(go.Bar(x=self.df_sample['regiao'], y=self.df_sample['acesso_internet_pct'], 
                            name='Internet'), row=1, col=1)
        fig.add_trace(go.Bar(x=self.df_sample['regiao'], y=self.df_sample['banda_larga_pct'], 
                            name='Banda Larga'), row=1, col=2)
        fig.add_trace(go.Bar(x=self.df_sample['regiao'], y=self.df_sample['dispositivos_moveis_pct'], 
                            name='Móveis'), row=2, col=1)
        fig.add_trace(go.Bar(x=self.df_sample['regiao'], y=self.df_sample['computador_pct'], 
                            name='Computadores'), row=2, col=2)
        
        fig.update_layout(height=600, showlegend=False, title_text="Indicadores de Inclusão Digital por Região")
        fig.write_html(os.path.join(self.figures_dir, 'inclusao_digital_interativo.html'))
    
    def analyze_economic_opportunities(self):
        """Analisa as oportunidades econômicas."""
        print("Analisando oportunidades econômicas...")
        
        if self.df_sample is None:
            self.create_sample_data()
        
        # Gráfico de oportunidades econômicas
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        
        # Cursos Online
        axes[0,0].bar(self.df_sample['regiao'], self.df_sample['cursos_online_pct'])
        axes[0,0].set_title('Acesso a Cursos Online por Região (%)')
        axes[0,0].tick_params(axis='x', rotation=45)
        
        # Teletrabalho
        axes[0,1].bar(self.df_sample['regiao'], self.df_sample['teletrabalho_pct'], color='orange')
        axes[0,1].set_title('Teletrabalho por Região (%)')
        axes[0,1].tick_params(axis='x', rotation=45)
        
        # Empreendedorismo Digital
        axes[1,0].bar(self.df_sample['regiao'], self.df_sample['empreendedorismo_digital_pct'], color='green')
        axes[1,0].set_title('Empreendedorismo Digital por Região (%)')
        axes[1,0].tick_params(axis='x', rotation=45)
        
        # Renda Média
        axes[1,1].bar(self.df_sample['regiao'], self.df_sample['renda_media'], color='red')
        axes[1,1].set_title('Renda Média por Região (R$)')
        axes[1,1].tick_params(axis='x', rotation=45)
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.figures_dir, 'oportunidades_economicas.png'), dpi=300, bbox_inches='tight')
        plt.close()
    
    def correlation_analysis(self):
        """Analisa correlações entre inclusão digital e oportunidades econômicas."""
        print("Analisando correlações...")
        
        if self.df_sample is None:
            self.create_sample_data()
        
        # Scatter plots para visualizar correlações
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        
        # Internet vs Renda
        axes[0,0].scatter(self.df_sample['acesso_internet_pct'], self.df_sample['renda_media'])
        axes[0,0].set_xlabel('Acesso à Internet (%)')
        axes[0,0].set_ylabel('Renda Média (R$)')
        axes[0,0].set_title('Correlação: Internet vs Renda')
        
        # Internet vs Cursos Online
        axes[0,1].scatter(self.df_sample['acesso_internet_pct'], self.df_sample['cursos_online_pct'])
        axes[0,1].set_xlabel('Acesso à Internet (%)')
        axes[0,1].set_ylabel('Cursos Online (%)')
        axes[0,1].set_title('Correlação: Internet vs Cursos Online')
        
        # Internet vs Teletrabalho
        axes[1,0].scatter(self.df_sample['acesso_internet_pct'], self.df_sample['teletrabalho_pct'])
        axes[1,0].set_xlabel('Acesso à Internet (%)')
        axes[1,0].set_ylabel('Teletrabalho (%)')
        axes[1,0].set_title('Correlação: Internet vs Teletrabalho')
        
        # Internet vs Empreendedorismo Digital
        axes[1,1].scatter(self.df_sample['acesso_internet_pct'], self.df_sample['empreendedorismo_digital_pct'])
        axes[1,1].set_xlabel('Acesso à Internet (%)')
        axes[1,1].set_ylabel('Empreendedorismo Digital (%)')
        axes[1,1].set_title('Correlação: Internet vs Empreendedorismo')
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.figures_dir, 'correlacoes_scatter.png'), dpi=300, bbox_inches='tight')
        plt.close()
        
        # Calcular coeficientes de correlação
        correlations = {
            'Internet vs Renda': self.df_sample['acesso_internet_pct'].corr(self.df_sample['renda_media']),
            'Internet vs Cursos Online': self.df_sample['acesso_internet_pct'].corr(self.df_sample['cursos_online_pct']),
            'Internet vs Teletrabalho': self.df_sample['acesso_internet_pct'].corr(self.df_sample['teletrabalho_pct']),
            'Internet vs Empreendedorismo': self.df_sample['acesso_internet_pct'].corr(self.df_sample['empreendedorismo_digital_pct'])
        }
        
        print("\n=== COEFICIENTES DE CORRELAÇÃO ===")
        for key, value in correlations.items():
            print(f"{key}: {value:.3f}")
        
        return correlations
    
    def regression_analysis(self):
        """Realiza análise de regressão."""
        print("Realizando análise de regressão...")
        
        if self.df_sample is None:
            self.create_sample_data()
        
        # Preparar dados para regressão
        X = self.df_sample[['acesso_internet_pct', 'banda_larga_pct', 'computador_pct']].values
        y = self.df_sample['renda_media'].values
        
        # Normalizar dados
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        # Ajustar modelo de regressão
        model = LinearRegression()
        model.fit(X_scaled, y)
        
        # Fazer predições
        y_pred = model.predict(X_scaled)
        r2 = r2_score(y, y_pred)
        
        print(f"\nR² Score: {r2:.3f}")
        print(f"Coeficientes: {model.coef_}")
        print(f"Intercepto: {model.intercept_:.2f}")
        
        # Visualizar resultados da regressão
        plt.figure(figsize=(10, 6))
        plt.scatter(y, y_pred, alpha=0.7)
        plt.plot([y.min(), y.max()], [y.min(), y.max()], 'r--', lw=2)
        plt.xlabel('Renda Real (R$)')
        plt.ylabel('Renda Predita (R$)')
        plt.title(f'Regressão Linear: Renda vs Indicadores Digitais (R² = {r2:.3f})')
        plt.tight_layout()
        plt.savefig(os.path.join(self.figures_dir, 'regressao_linear.png'), dpi=300, bbox_inches='tight')
        plt.close()
        
        return model, r2
    
    def generate_summary_report(self):
        """Gera um relatório resumo das análises."""
        print("Gerando relatório resumo...")
        
        if self.df_sample is None:
            self.create_sample_data()
        
        # Calcular estatísticas resumo
        stats = {
            'media_acesso_internet': self.df_sample['acesso_internet_pct'].mean(),
            'media_renda': self.df_sample['renda_media'].mean(),
            'regiao_maior_acesso': self.df_sample.loc[self.df_sample['acesso_internet_pct'].idxmax(), 'regiao'],
            'regiao_menor_acesso': self.df_sample.loc[self.df_sample['acesso_internet_pct'].idxmin(), 'regiao'],
            'regiao_maior_renda': self.df_sample.loc[self.df_sample['renda_media'].idxmax(), 'regiao'],
            'regiao_menor_renda': self.df_sample.loc[self.df_sample['renda_media'].idxmin(), 'regiao']
        }
        
        return stats

if __name__ == "__main__":
    # Inicializar analisador
    processed_data_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'processed')
    analyzer = InclusaoDigitalAnalyzer(processed_data_dir)
    
    # Carregar dados (se existirem)
    analyzer.load_data()
    
    # Criar dados de exemplo para demonstração
    analyzer.create_sample_data()
    
    # Executar análises
    print("\n" + "="*50)
    print("INICIANDO ANÁLISES")
    print("="*50)
    
    # Análise exploratória
    correlation_matrix = analyzer.exploratory_analysis()
    
    # Análise de inclusão digital
    analyzer.analyze_digital_inclusion()
    
    # Análise de oportunidades econômicas
    analyzer.analyze_economic_opportunities()
    
    # Análise de correlações
    correlations = analyzer.correlation_analysis()
    
    # Análise de regressão
    model, r2 = analyzer.regression_analysis()
    
    # Relatório resumo
    stats = analyzer.generate_summary_report()
    
    print("\n" + "="*50)
    print("RESUMO DOS RESULTADOS")
    print("="*50)
    print(f"Média de acesso à internet: {stats['media_acesso_internet']:.1f}%")
    print(f"Média de renda: R$ {stats['media_renda']:.2f}")
    print(f"Região com maior acesso: {stats['regiao_maior_acesso']}")
    print(f"Região com menor acesso: {stats['regiao_menor_acesso']}")
    print(f"Região com maior renda: {stats['regiao_maior_renda']}")
    print(f"Região com menor renda: {stats['regiao_menor_renda']}")
    
    print("\nAnálises concluídas. Verifique a pasta 'reports/figures' para os gráficos gerados.")

